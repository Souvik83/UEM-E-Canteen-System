MongoDB datebase start : sudo mongod --dbpath /System/Volumes/Data/data/db

Admin REgister : /Uem-canteen/Admin/register
