require("dotenv").config()
//Initialise Express App...
const Express = require('express');
const app = Express();
const path = require('path');
const hbs = require('hbs');
const ejs = require('ejs')
const cookie_parser = require("cookie-parser")
const session = require("express-session")
const flash = require("express-flash")
const MongoDbStore = require('connect-mongo');
//Routers import
const postRequests = require("./routers/postRequests");
const getRequests = require("./routers/getRequests")
const async = require('hbs/lib/async');
const { default: mongoose } = require("mongoose");


//db
require("./database/databaseConn")

//Connections :
const Host = "127.0.0.1";
const Port = 8800;

//Creating paths-
const publicFolderPath = path.join(__dirname, "../public")
const pertialFolderPath = path.join(__dirname, "../server/views/partials")

//Built-in middleware to read all file formats...
app.use(Express.static(publicFolderPath));

app.use(cookie_parser())

// Set Tamplate engine
app.set('view engine', 'ejs')

// Set Partials
hbs.registerPartials(pertialFolderPath)

//DATA RELATED
app.use(Express.json())
app.use(Express.urlencoded({ extended: false }))

//Express Flash middleware
app.use(flash())


//Session config...
app.use(
    session({
        secret: process.env.SESSION_SECRET_KEY,
        resave: false,
        saveUninitialized: false,
        unset: 'destroy',
        store: MongoDbStore.create({
            mongoUrl: 'mongodb://0.0.0.0:27017/uemCanteen',
        })
    })
);

//Global middleware...
app.use((req, res, next)=>{
    res.locals.session = req.session
    next()
})

//Register router... ## HTTP requests are provided in the router file ##
app.use(postRequests)
app.use(getRequests)


//Listing Server...
app.listen(Port, () => {
    console.log(`\n Listing to port :${Port} & Hosted in : Localhost || Click here: ${Host}:${Port}`)
})