const express = require("express")
const Router = new express.Router()
const userCollection = require("../models/users")
const jwt = require("jsonwebtoken")
const async = require("hbs/lib/async")
const users = require("../models/users")
const menu = require("../models/menus")
const { param } = require("express/lib/request")
//const axios = require("axios")

//Rest Api : Create

// exports.create = async (req, res) => {
//     try {
//         const login_cookie_token = req.cookies.jwtLOGIN
//         const varifyUser = await jwt.verify(login_cookie_token, process.env.TOKEN_SECRET_KEY)

//         console.log(varifyUser)

//         if (varifyUser) {
//             const Uid = varifyUser._id
//             const noteTitle = req.body.noteTitle
//             const noteContent = req.body.noteContent

//             const d = new Date();
//             let day = d.getDate();
//             let year = d.getFullYear();
//             let month = d.getMonth();

//             const user_Notes = new userNotes({
//                 userID: Uid,
//                 userNoteTitle: noteTitle,
//                 userNoteContent: noteContent,
//                 noteCreatedDate: `${day}.${month}.${year}`
//             })
//             //save data
//             await user_Notes.save()
//             res.redirect("/user")
//         } else {
//             res.redirect("/")
//         }
//     } catch (error) {
//         console.log("User not Authenticated")
//         res.redirect("/")
//     }

// }


//Rest api : Read
exports.find = async (req, res) => {
    try {

        var param = [req.query]
        //console.log("Id : ", param[0].id)
        const userData = await userCollection.findOne({ _id: param[0].id })
        // => // // #### Read notes :#####
        //const user_Notes = [await userNotes.find({ userID: param[0].id }).sort({ noteUpdateDateForSorting: -1 })]
        //console.log(user_Notes[0].length)
        res.send({
            userData: userData
        })
    } catch (err) {
        console.log("Error", err)
    }
}





//Rest api : Update/patch
exports.update = async (req, res) => {
    try {
        const login_cookie_token = req.cookies.jwtLOGIN
        const varifyUser = await jwt.verify(login_cookie_token, process.env.TOKEN_SECRET_KEY)

        if (varifyUser) {
            const Uid = varifyUser._id
            const noteTitle = req.body.updatenotetitle
            const noteContent = req.body.updatenote

            var param = [req.query]
            console.log("Id : ", param[0].id)
            const d = new Date();
            let day = d.getDate();
            let year = d.getFullYear();
            let month = d.getMonth();
            const noteUpdateDate = await userNotes.updateOne({ _id: param[0].id }, { $set: { noteUpdateDate: `${day}.${month}.${year}` } })
            const noteTitleUpdate = await userNotes.updateOne({ _id: param[0].id }, { $set: { userNoteTitle: noteTitle } })
            const noteUpdateContent = await userNotes.updateOne({ _id: param[0].id }, { $set: { userNoteContent: noteContent } })

            res.redirect("/user")
        } else {
            res.redirect("/")
        }

        // => // // #### Read notes :#####
        // const user_Notes = [await userNotes.find({userID:param[0].id}).sort({noteCreatedDate:-1})]
        //console.log(user_Notes[0].length)

    } catch (err) {
        console.log("Error", err)
    }
}


//Rest api : Delete
exports.delete = async (req, res) => {
    try{
    const login_cookie_token = req.cookies.jwtAdminLOGIN
    const varifyUser = await jwt.verify(login_cookie_token, "uemCanteenadmin")

    if (varifyUser) {
        var param = [req.query]
        const deleteUser = await users.deleteOne({ _id: param[0].id })
        res.redirect("/Usermanagement")
    }
}catch(err){
    console.log(err)
}


}

exports.deleteMenu = async (req, res) =>{
    try{
        const login_cookie_token = req.cookies.jwtAdminLOGIN
        const varifyUser = await jwt.verify(login_cookie_token, "uemCanteenadmin")
    
        if (varifyUser) {
            var param = [req.query]
            const deleteMenu = await menu.deleteOne({ _id: param[0].id })
            res.redirect("/Foodmanagement")
        }
    }catch(err){
        console.log(err)
    }
}

