const async = require("hbs/lib/async")
const jwt = require("jsonwebtoken")

//Check if user authenticated then they should not go to Login or Registration
async function guest(req, res, next){
    const login_cookie_token = req.cookies.jwtLOGIN
    //const varifyUser = await jwt.verify(login_cookie_token, "guestTokenKey")

    if(!login_cookie_token){
        console.log("Working")
        return next()
    }
    else{
        console.log("Guest redirect Working")
        res.redirect("/Main")
    }
}

module.exports = guest 