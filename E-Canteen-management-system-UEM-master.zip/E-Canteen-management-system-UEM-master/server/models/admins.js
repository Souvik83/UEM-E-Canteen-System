// const adminSchema = new Schema ({
//     name : {type: String, required: true},
//     logInId : {type: Number, required: true},
//     pass : {type: String, required: true}
// })

// const Admin = mongoose.model('admins', adminSchema)

// module.exports = Admin

const mongoose = require("mongoose")
const bcrypt = require("bcrypt")
const validator = require('validator')
const jwt = require('jsonwebtoken')


// Creating schema for Admin
const admins = new mongoose.Schema({
    adminname: {
        type: String,
        required: true,
        maxlength: 25
    },
    logInId: {
        type: Number,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    },
    date:{
        type:Date,
        default:Date.now
    },
    token:[{
        token:{
            type:String,
            required:true
        }
    }]
})

//Token to register in database after user registration...

admins.methods.generateAuthToken = async function(){
    try {
        console.log(this._id)
        const token = jwt.sign({_id:this._id.toString()}, "uemcanteenadmins")
        console.log(token)
        this.token = this.token.concat({token:token})
        await this.save()
        return token
    } catch (error) {
        console.log(error)
    }
}


//using Middleware performing hashing...
admins.pre("save", async function (next) {

    if (this.isModified("password")) {
        this.password = await bcrypt.hash(this.password, 4)
        next()
    }
})

//Initialise the module...
const RegisterAdmins = new mongoose.model("RegisterAdmins", admins)

//Export
module.exports = RegisterAdmins
