const express = require("express")
const async = require("hbs/lib/async")
const Router = new express.Router()
const auth = require("../middleware/auth")
const guest = require("../middleware/guest")
const userCollection = require("../models/users")
const adminCollection = require("../models/admins")
const menuCollection = require("../models/menus")
const cartCollection = require("../models/cart")
const Order = require("../models/orders")
const jwt = require('jsonwebtoken')
const api = require("../api/api")
const axios = require("axios")
const bcrypt = require('bcrypt')
//let alert = require('alert')
let moment = require("moment")

//GET requiests...

//API 
Router.get("/api/user", api.find)
Router.get('/user/delete-user', api.delete)
Router.get("/menu/delete-menuItem", api.deleteMenu)

//Home page...
Router.get("/", (req, res) => {
    res.status(200).render("index")
})

Router.get("/verify-Email", async (req, res) => {
    const v_code = req.query.v_code
    const v_email = req.query.email
    console.log("OTP : ", v_code, "And ", v_email)
    if (v_code && v_email) {
        const userData = await userCollection.findOne({ userEmail: v_email })

        if (userData.isVarified == false) {
            if (v_code == userData.otp) {
                console.log("Verification Successfully complete")
                await userCollection.updateOne({ otp: v_code }, { $set: { isVarified: true } })
                req.flash('success', "You are successfully verified.")
                res.redirect("/Student-login")

            }
        } else {
            req.flash('success', "You are already verified.")
            res.redirect("/Student-login")
        }
    } else {
        req.flash('error', "Something went wrong. Please re-send verification code.")
        res.redirect("/Student-login")
    }

})


Router.get("/Main", auth, async (req, res) => {
    try {
        const login_cookie_token = req.cookies.jwtLOGIN
        const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
        const userData = await userCollection.findOne({ _id: verifyUser._id })
        const Cart = await cartCollection.find({ customerId: verifyUser._id })
        // console.log("Data of user", userData)
        console.log("Data of Cart", Cart)
        if (verifyUser) {
            usersId = verifyUser._id
            //Make a get req to api/user using axios...
            axios.get(`http://localhost:8800/api/user?id=${usersId}`)
                .then(function (response) {
                    console.log(response.data)
                    res.render("Main", {
                        userID: response.data.userData._id,
                        userName: response.data.userData.username,
                        userEmail: response.data.userData.userEmail,
                        cart: Cart[0],

                    })
                }).catch(err => {
                    console.log(err)
                })
        }
    } catch (error) {
        console.log(error)
    }

})


Router.get("/Chinese-Canteen", auth, async (req, res) => {
    //get user data
    try {
        // console.log("Hello : ",auth.Authentication)
        const login_cookie_token = req.cookies.jwtLOGIN
        const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
        const userData = await userCollection.findOne({ _id: verifyUser._id })
        const menu = await menuCollection.find({ Rname: "Chinese Canteen" })
        const Cart = await cartCollection.find({ customerId: verifyUser._id })

        //console.log("Data of user", userData)
         console.log("Data of Cart", Cart)
        if (verifyUser) {
            usersId = verifyUser._id
            //Make a get req to api/user using axios...
            axios.get(`http://localhost:8800/api/user?id=${usersId}`)
                .then(function (response) {
                    // console.log(response.data)
                    res.render("chineseCanteen", {
                        userID: response.data.userData._id,
                        userName: response.data.userData.username,
                        userEmail: response.data.userData.userEmail,
                        menuChinese: menu,
                        cart: Cart[0],
                    })
                }).catch(err => {
                    console.log(err)
                })
        }
    } catch (error) {
        console.log(error)
    }
})

Router.get("/Bengali-Canteen", auth, async (req, res) => {
    //get user data
    try {
        // console.log("Hello : ",auth.Authentication)
        const login_cookie_token = req.cookies.jwtLOGIN
        const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
        const userData = await userCollection.findOne({ _id: verifyUser._id })
        const menu = await menuCollection.find({ Rname: "Bengali Canteen" })
        const Cart = await cartCollection.find({ customerId: verifyUser._id })
        
        //console.log("Data of user", menu)
        if (verifyUser) {
            usersId = verifyUser._id
            //Make a get req to api/user using axios...
            axios.get(`http://localhost:8800/api/user?id=${usersId}`)
                .then(function (response) {
                    console.log(response.data)
                    res.render("bengaliCanteen", {
                        userID: response.data.userData._id,
                        userName: response.data.userData.username,
                        userEmail: response.data.userData.userEmail,
                        menuBengali: menu,
                        cart: Cart[0],
                    })
                }).catch(err => {
                    console.log(err)
                })
        }
    } catch (error) {
        console.log(error)
    }
})

Router.get("/Night-Canteen", auth, async (req, res) => {
    //get user data
    try {
        // console.log("Hello : ",auth.Authentication)
        const login_cookie_token = req.cookies.jwtLOGIN
        const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
        const userData = await userCollection.findOne({ _id: verifyUser._id })
        const menu = await menuCollection.find({ Rname: "Night Canteen" })
        const Cart = await cartCollection.find({ customerId: verifyUser._id })
        //console.log("Data of user", menu)
        if (verifyUser) {
            usersId = verifyUser._id
            //Make a get req to api/user using axios...
            axios.get(`http://localhost:8800/api/user?id=${usersId}`)
                .then(function (response) {
                    console.log(response.data)
                    res.render("nightCanteen", {
                        userID: response.data.userData._id,
                        userName: response.data.userData.username,
                        userEmail: response.data.userData.userEmail,
                        menuNightCanteen: menu,
                        cart: Cart[0],
                    })
                }).catch(err => {
                    console.log(err)
                })
        }
    } catch (error) {
        console.log(error)
    }
})


//User Login...
Router.get("/Student-login", guest, (req, res) => {
    res.render("login")
})

//User Logout...
Router.get('/user/logout', auth, async (req, res) => {
    try {
        res.clearCookie("jwtLOGIN")
        console.log("User successfully logged out")

        await req.user.save()
        res.redirect("/Student-login")

    } catch (error) {
        console.log(error)
    }
})

//Admin Logout...
Router.get('/admin/logout', auth, async (req, res) => {
    try {
        res.clearCookie("jwtAdminLOGIN")
        console.log("User successfully logged out")

        await req.user.save()
        res.redirect("/Admin-login")

    } catch (error) {
        console.log(error)
    }
})

//New registration...
Router.get('/Registration', guest, (req, res) => {
    res.render('registration')
})

//Order page...
Router.get('/yourOrders', auth, async (req, res) => {
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    const userData = await userCollection.findOne({ _id: verifyUser._id })
    const Cart = await cartCollection.find({ customerId: verifyUser._id })
    //console.log('Cart : ', req.session.cart[verifyUser._id])
    console.log("Data of Cart", req.session.cart)
    if (verifyUser) {
        usersId = verifyUser._id
        res.render("orderPage", {
            users: userData,
            cart: Cart[0]
        })

    }
})

Router.get("/Orderconfirmed", async (req, res) => {
    try {
        const login_cookie_token = req.cookies.jwtLOGIN
        const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
        const userData = await userCollection.findOne({ _id: verifyUser._id })
        //console.log('Cart : ', req.session.cart[verifyUser._id])
        if (verifyUser) {
            console.log("Module working")
            usersId = verifyUser._id
            res.render("orderConfirmed", {
                users: userData
            })

        }

    } catch (e) {
        console.log(e)
        res.render("orderConfirmed", { users: userData })
    }
})

//Reciept page...

Router.get("/reciept", auth, async (req, res) => {
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    const userData = await userCollection.findOne({ _id: verifyUser._id })
    //const userOrder = await Order.findOne({customerId: verifyUser._id})
    const totalOrder = await Order.find({ customerId: verifyUser._id })
    const Orders = await Order.find({ customerId: verifyUser._id }).sort({ _id: -1 }).limit(1)

    console.log('Order : ', Orders)

    if (verifyUser) {
        usersId = verifyUser._id
        res.render("reciept", {
            users: userData,
            lastOrder: Orders,
            moment: moment,
            totalOrder: totalOrder.length,
            orderID: Orders[0]._id,
            order: Orders[0]
        })
    }
})

//User Orders...

Router.get("/user/Orders", auth, async (req, res) => {
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    const userOrder = await Order.findOne({ customerId: verifyUser._id })
    const Orders = await Order.find({ customerId: verifyUser._id })
    const Cart = await cartCollection.find({customerId: verifyUser._id})
    console.log('Order : ', Orders)
    console.log(verifyUser)
    if (verifyUser) {

        res.render("userOrders", {
            userID: verifyUser._id,
            usersName: verifyUser.username,
            userOrder: userOrder,
            ordersOfUsers: Orders,
            moment: moment,
            cart : Cart[0]
        })

    }
})

//Account...
Router.get("/user/Account", auth, async(req, res)=>{
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    let userData = await userCollection.findOne({ _id : verifyUser })
    const Cart = await cartCollection.find({customerId: verifyUser._id})
    res.render("myAcc", {
        userData,
        usersName: verifyUser.username,
        cart : Cart[0],
        moment: moment,
    })

})

Router.get("/genBill", auth, async (req, res) => {
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    const userData = await userCollection.findOne({ _id: verifyUser._id })
    //const userOrder = await Order.findOne({customerId: verifyUser._id})
    const totalOrder = await Order.find({ customerId: verifyUser._id })

    console.log("Param", req.query.id)
    let orderId = req.query.id
    const Orders = await Order.find({ _id: orderId })
    console.log(Orders)
    res.render("genBill", {
        order: Orders[0],
        users: userData,
        moment: moment,
        totalOrder: totalOrder.length,
        orderID: Orders[0]._id,
    })

})

//About page...
Router.get("/About", (req, res) => {
    res.render("about")
})
//Admin dash board...
Router.get("/Uem-canteen/Admin/register", (req, res) => {
    res.render("registerAdmin")
})
//Admin LogIN page...
Router.get("/Admin-login", (req, res) => {
    res.render("admin-login")
})
//Admin dash board...
Router.get("/Dashboard", async (req, res) => {
    const admin_login_cookie_token = req.cookies.jwtAdminLOGIN
    const verifyUser = await jwt.verify(admin_login_cookie_token, "uemCanteenadmin")
    const adminData = await adminCollection.findOne({ _id: verifyUser._id })
    const menu = await menuCollection.find({ Rname: adminData.adminname })
    const users = await userCollection.find()
    console.log("Data of Admin", adminData)
    if (verifyUser) {
        usersId = verifyUser._id
        //Make a get req to api/user using axios...
        // axios.get(`http://localhost:8800/api/user?id=${usersId}`)

        res.render("dash", {
            Admin: adminData,
            menuCard: menu,
            users: users
        })

    }

})
//Admin  usermanagement...
Router.get("/Usermanagement", async (req, res) => {
    const admin_login_cookie_token = req.cookies.jwtAdminLOGIN
    const verifyUser = await jwt.verify(admin_login_cookie_token, "uemCanteenadmin")
    const adminData = await adminCollection.findOne({ _id: verifyUser._id })
    const users = await userCollection.find()

    if (verifyUser) {
        usersId = verifyUser._id

        res.render("usermanagement", {
            Admin: adminData,
            users: users
        })

    }
})
//Admin food management...
Router.get("/Foodmanagement", async (req, res) => {
    const admin_login_cookie_token = req.cookies.jwtAdminLOGIN
    const verifyUser = await jwt.verify(admin_login_cookie_token, "uemCanteenadmin")
    const adminData = await adminCollection.findOne({ _id: verifyUser._id })
    const menu = await menuCollection.find({ Rname: adminData.adminname })
    if (verifyUser) {
        usersId = verifyUser._id

        res.render("Foodmanagement", {
            Admin: adminData,
            menuCard: menu
        })

    }

})
//Admin  management...
Router.get("/Ordermanagement", async(req, res) => {
    const admin_login_cookie_token = req.cookies.jwtAdminLOGIN
    const verifyUser = await jwt.verify(admin_login_cookie_token, "uemCanteenadmin")
    const users = await userCollection.find()
    const adminData = await adminCollection.findOne({ _id: verifyUser._id })
    const adminName = adminData.adminname
    const orderData = await Order.find({"items.items.RName": adminName}).sort({_id:-1})
    console.log("Or ", orderData.customerDetails)
    console.log("Op ", adminName)
    res.render("Ordermanagement" , {
        ordersByCanteen : orderData,
        moment:moment,
        users : users,
        admin : adminData
    })
})

//University Admin Manipulator...
Router.get("/uem-e-canteen/admin/order-management", async(req, res) => {
    const users = await userCollection.find()
    const adminData = await adminCollection.find()
    const orderData = await Order.find().sort({_id:-1})
    console.log("Or ", orderData)
    //console.log("Op ", adminName)
    res.render("universityAdminOrder" , {
        ordersByCanteen : orderData,
        moment:moment,
        users : users,
        admin : adminData
    })
})


//Error 404
Router.get("*", (req, res) => {
    res.status(404).send("404")
})

// Export the page
module.exports = Router