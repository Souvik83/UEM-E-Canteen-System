require("dotenv").config()
const express = require("express")
const async = require("hbs/lib/async")
const Router = new express.Router()
const bcrypt = require('bcrypt')
const jwt = require("jsonwebtoken")
const flash = require("express-flash")
const mongoose = require("mongoose")
//Models import
const userSchema = require("../models/users")
const adminSchema = require("../models/admins")
const Order = require("../models/orders")
const cartCollection = require("../models/cart")
const menuSchema = require("../models/menus")
//Middleware
const auth = require("../middleware/auth")
// Includes crypto module
const crypto = require('crypto');
var nodemailer = require('nodemailer');
const Orders = require("../models/orders")

//POST requiests...

// // ### Register user ### // //
Router.post("/User/Register", async (req, res) => {
    try {

        console.log(req.body.username)
        const username = req.body.username
        const userEnrollment = req.body.userEnrollment
        const phone = req.body.contactNo
        const Email = req.body.userEmail
        const userBlock = req.body.userBlock
        const userRoom = req.body.userRoom
        const password = req.body.password

        // Defining key
        const secret = Email;

        // OTP Hash method
        const hash = await bcrypt.hash(secret, 4)


        // Displays output
        console.log(hash);

        //Algorithm for registration...
        const registerData = new userSchema({
            username: username,
            enrollmentNo: userEnrollment,
            userEmail: Email,
            contactNo: phone,
            blockName: userBlock,
            roomNo: userRoom,
            password: password,
            isVarified: false,
            otp: hash
        })

        //Creating token for the particuler user
        const token = await registerData.generateAuthToken()
        console.log(token)

        res.cookie("jwt", token, {
            expires: new Date(Date.now() + 300000000)
        })

        //Sava the data in database
        const userData = await registerData.save()

        // create reusable transporter object using the default SMTP transport
        const transporter = nodemailer.createTransport({
            port: 587,               // true for 465, false for other ports
            host: "smtp.gmail.com",
            auth: {
                user: 'arghyabanerjee59@gmail.com',
                pass: "yqyuxhmnywuymryu",
            },
            // secure: true,
        });

        const mailData = {
            from: 'uem.canteen@iem.com',  // sender address
            to: Email,   // list of receivers
            subject: 'Verify your E-mail',
            text: 'University Of Engineering & Management',
            html: `<b style="font-size:20px"> <center>UEM Canteen Verification!!<center/> </b> <br>
              <center><p style="font-size:15px"> Hi <span style="color: crimson ">${username}</span>,</p> <br> <p style="font-size:20px ">Thanks for getting started with UEM Canteen.</p> <br>
              We need a little more information to complete your registration, including a confirmation of your email address. <br>
              <br>
              Please Click below to verify your E-mail in UEM Canteen Management  </center> <br/>  
              <center> <a style="display:flex; border-radius: 50px; text-decoration: none; background-color: crimson; width: 100px; height: 30px; color: white; text-align: center" href="http://127.0.0.1:8800/verify-Email?email=${Email}&v_code=${hash}"> <span style="margin: auto">Verify Link</span></a> </center>`,
        };

        //Sending the mail

        transporter.sendMail(mailData, (err, info) => {
            if (err)
                console.log(err)
            else {
                req.flash('success', "Verification Code sent successfully. Please visit you E-mail")
                res.redirect("/Student-login")
            }

            console.log("Message sent: %s", info.messageId);
            //  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

            //  // Preview only available when sending through an Ethereal account
            console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
        });



    }
    catch (e) {
        if(e.error){
            req.flash('error', "Please enter valid data")
            res.redirect("/Registration")
        }
            if(e.code == 11000){
                const username = req.body.username
                const userEnrollment = req.body.userEnrollment
                const contactNo = req.body.contactNo
                const userEmail = req.body.userEmail
                const userBlock = req.body.userBlock
                const userRoom = req.body.userRoom

                key = Object.keys(e.keyValue)
                let keyValue = key[0]
                req.flash('error', `${keyValue.charAt(0).toUpperCase() + keyValue.slice(1)} already exists`)
                req.flash('userName', username)
                req.flash('userEnrollment', userEnrollment)
                req.flash('contactNo', contactNo)
                req.flash('userEmail', userEmail)
                req.flash('userBlock', userBlock)
                req.flash('userRoom', userRoom)
                res.redirect("/Registration")
            }
                
    }
})

Router.post("/resendverificationcode", async (req, res) => {

    try {
        const inputEmail = req.body.Uemail
        const userData = await userSchema.findOne({ userEmail: inputEmail })

        if (userData) {
            // Defining key
            const secret = userData.userEmail;

            // Calling createHash method
            const hash = await bcrypt.hash(secret, 4)
            await userSchema.updateOne({ userEmail: inputEmail }, { $set: { otp: hash } })

            const transporter = nodemailer.createTransport({
                port: 587,
                host: "smtp.gmail.com",
                auth: {
                    user: 'arghyabanerjee59@gmail.com',
                    pass: "yqyuxhmnywuymryu",
                },
                // secure: true,
            });

            const mailData = {
                from: 'uem.canteen@iem.com',
                to: userData.userEmail,
                subject: 'E-mail verification from UEM Canteen',
                text: 'University Of Engineering & Management',
                html: `<b style="font-size:20px"> <center>UEM Canteen Verification!!<center/> </b> <br>
              <center><p style="font-size:15px"> Hi <span style="color: crimson ">${userData.username}</span>,</p> <br> <p style="font-size:20px ">Thanks for getting started with UEM Canteen.</p> <br>
              We need a little more information to complete your registration, including a confirmation of your email address. <br>
              <br>
              Please Click below to verify your E-mail in UEM Canteen.</center> <br/>  
              <center> <a style="display:flex; border-radius: 50px; text-decoration: none; background-color: crimson; width: 100px; height: 30px; color: white; text-align: center" href="http://127.0.0.1:8800/verify-Email?email=${userData.userEmail}&v_code=${hash}"> <span style="margin: auto">Verify Link</span></a> </center>`,
            };

            //Sending the mail

            transporter.sendMail(mailData, (err, info) => {
                if (err)
                    console.log(err)
                else {
                    req.flash('success', "Verification Code sent successfully")
                    res.redirect("/Student-login")
                }

                console.log("Message sent: %s", info.messageId);
            });
        }
        else {
            req.flash('error', "Enter a valid Registered E-mail.")
            res.redirect("/Student-login")
        }





    } catch (error) {
        console.log(error)
    }


})

// // ### Login user ### // //

Router.post("/user/login", async (req, res) => {
    //Algorithm implementation for login
    try {
        const Enroll = req.body.loginUserName
        const password = req.body.LogInpassword
        //Fetch data froom database
        const fechedData = await userSchema.find({ enrollmentNo: Enroll })
        console.log(fechedData)
        //Checking data is available or no (user exists or not)
        if (fechedData.length < 1) {
            throw new Error("User doesn't exist")
        }
        //password checking...
        bcrypt.compare(password, fechedData[0].password, async function (err, result) {

            // result == true
            if (!result) {
                //Error Msg showing to front-end
                req.flash('error', "Opps!! Wrong Credential")
                req.flash('userId', Enroll)
                req.flash('password', password)
                res.redirect("/Student-login")
            }
            //Authentication by JWT(JSON web token)
            if (result) {

                if (fechedData[0].isVarified == true) {
                    //Generating token
                    const token = await jwt.sign({
                        username: fechedData[0].username,
                        userEmail: fechedData[0].userEmail,
                        _id: fechedData[0]._id
                    },
                        "uemCanteen",
                        {
                            expiresIn: "24h"
                        }
                    )

                    //Generating guest token
                    const guestToken = await jwt.sign({
                        username: fechedData[0].username,
                        userEmail: fechedData[0].userEmail,
                        _id: fechedData[0]._id
                    },
                        "guestTokenKey",
                        {
                            expiresIn: "24h"
                        }
                    )
                    //COOKIES
                    res.cookie("jwtLOGIN", token, {
                        expires: new Date(Date.now() + 300000000)
                    })

                    // Guest COOKIe store
                    res.cookie("guestToken", guestToken, {
                        expires: new Date(Date.now() + 300000000)
                    })

                    //Response
                    res.redirect("/Main")
                } else {
                    req.flash('error', "You are not varified!! Please verify your E-mail.")
                    res.redirect("/Student-login")
                }

            }
        });
    } catch (error) {
        req.flash('error', "Sorry! User doesn't exist")
        // req.flash('userId', Enroll)
        // req.flash('password', password)
        res.redirect("/Student-login")
        console.log(error)

    }
})

// // ### Update Cart ### // //

Router.post("/update-cart", async (req, res) => {
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    console.log("AXIOS: ", req.body)

    try {
        let productId = req.body.itemData._id
        let productName = req.body.itemData.name
        let productRname = req.body.itemData.Rname
        let productImage = req.body.itemData.image
        let productPrice = req.body.itemData.price
        let userId = verifyUser._id

        let Cart = await cartCollection.findOne({ customerId: verifyUser._id })

        if (Cart) {
            //cart exists for user
            let itemIndex = Cart.items.findIndex(p => p.productId == productId);
            console.log(itemIndex)
            if (itemIndex > -1) {
                //product exists in the cart, update the quantity
                let productItem = Cart.items[itemIndex];
                productItem.quantity += 1;
                //productItem.productPrice = productPrice * productItem.quantity
                Cart.items[itemIndex] = productItem;
                Cart.totalQty += 1
                Cart.totalPrice += productPrice
            } else {
                //product does not exists in cart, add new item
                Cart.items.push({
                    productId: productId,
                    quantity: 1,
                    productName: productName,
                    productPrice: productPrice,
                    RName: productRname,
                    productImage: productImage
                })
                Cart.totalQty += 1
                Cart.totalPrice += productPrice
            }
            Cart = await Cart.save();
            res.json({ totalQty: Cart.totalQty })
        } else {
            //no cart for user, create new cart
            const newCart = await cartCollection.create({
                customerId: userId,
                items: [{
                    productId: productId,
                    quantity: 1,
                    productName: productName,
                    productPrice: productPrice,
                    RName: productRname,
                    productImage: productImage
                }],
                totalQty: 1,
                totalPrice: productPrice
            });

            res.json({ totalQty: 1 })
        }

        // if(!Cart){
        //     const cartData = new cartCollection({
        //         customerId: req.body.userDataId,
        //         items: [{
        //             productId:productId,
        //             quantity:1,
        //             productName:productName,
        //             productPrice:productPrice,
        //             RName:productRname,
        //             productImage:productImage
        //         }],
        //         totalQty:1,
        //         totalPrice:productPrice
        //     })

        //      //Sava the data in database
        //      const cartDataSave = await cartData.save()


        // }else{
        //     let checkAvailablity = await cartCollection.find({ productId: req.body.itemData._id },{name:1, _id:0})
        //     console.log("AAAA",checkAvailablity)
        //     await cartCollection.updateOne({ productId: req.body.itemData._id }, {$set : {
        //         quantity : checkAvailablity + 1,
        //     }})
        //     await cartCollection.updateOne({ productId: req.body.itemData._id }, {$set : {
        //         productPrice : productPrice * quantity,
        //     }})
        // }

        // res.json({ total: Cart.totalQty })

    } catch (error) {
        console.log(error)
    }

    //For the first time creating cart...
    // if (!req.session.cart) {
    //     req.session.cart = {}
    // }
    // storing the cart value if already has some cart items...
    // let cart = req.session.cart

    // if (!cart[req.body.userDataId]) {

    //     cart[req.body.userDataId] = {
    //         items: {},
    //         totalQty: 0,
    //         totalPrice: 0
    //     }

    // }

    // if (!cart[req.body.userDataId].items[req.body.itemData._id]) {
    //     cart[req.body.userDataId].items[req.body.itemData._id] = {
    //         item: req.body.itemData,
    //         qty: 1
    //     }
    //     cart[req.body.userDataId].totalQty = cart[req.body.userDataId].totalQty + 1
    //     cart[req.body.userDataId].totalPrice = cart[req.body.userDataId].totalPrice + req.body.itemData.price
    // } else {
    //     cart[req.body.userDataId].items[req.body.itemData._id].qty = cart[req.body.userDataId].items[req.body.itemData._id].qty + 1
    //     cart[req.body.userDataId].totalQty = cart[req.body.userDataId].totalQty + 1
    //     cart[req.body.userDataId].totalPrice = cart[req.body.userDataId].totalPrice + req.body.itemData.price
    // }

    // console.log("Cart: ", req.session.cart[req.body.userDataId])


})

// // ### Register Admin ### // //

Router.post("/Admin/register", async (req, res) => {
    try {
        console.log(req.body.username)
        const canteenName = req.body.canteenName
        const canteenID = req.body.canteenID
        const LogInpassword = req.body.LogInpassword

        //Algorithm for registration...
        const registerData = new adminSchema({
            adminname: canteenName,
            logInId: canteenID,
            password: LogInpassword
        })

        //Creating token for the particuler user
        const token = await registerData.generateAuthToken()
        console.log(token)

        res.cookie("jwt", token, {
            expires: new Date(Date.now() + 300000000)
        })

        //Sava the data in database
        const adminData = await registerData.save()
        res.redirect("/Admin-login")

    }
    catch (e) {
        console.log(e)
    }
})

// // ### Log In Admin ### // //

Router.post("/admin/login", async (req, res) => {
    //Algorithm implementation for login
    try {
        const logInId = req.body.adminLogInId
        const password = req.body.adminLogInPass
        //Fetch data froom database
        const fechedData = await adminSchema.find({ logInId: logInId })
        console.log("Admiin Daata : ", fechedData)
        //Checking data is available or no (user exists or not)
        if (fechedData.length < 1) {
            throw new Error("Admin doesn't exist")
        }
        //password checking...
        bcrypt.compare(password, fechedData[0].password, async function (err, result) {

            // result == true
            if (!result) {
                res.send(`<Span>Wrong Credential <a href="/Student-login">Log In</a> again </Span>`)
                // throw new Error("Wrong Credential")
            }
            //Authentication by JWT(JSON web token)

            if (result) {

                console.log("Admin Log In Success")

                //Generating token
                const token = await jwt.sign({
                    adminname: fechedData[0].adminname,
                    adminID: fechedData[0].logInId,
                    _id: fechedData[0]._id
                },
                    "uemCanteenadmin",
                    {
                        expiresIn: "24h"
                    }
                )
                console.log("Admin token", token)
                //COOKIES
                res.cookie("jwtAdminLOGIN", token, {
                    expires: new Date(Date.now() + 300000000)
                })
                //Response
                res.redirect("/Dashboard")
            }
        });
    } catch (error) {
        res.send("Wrong Credential")

    }
})

// ### Add Menu ### //
Router.post("/admin/menu/add-menu", async (req, res)=> {
        const foodName = req.body.Foodname
        const foodPrice = req.body.Foodprice
        const foodImg = req.body.foodImg
        const Rname = req.body.Rname

        // add...
        const addFoodData = new menuSchema({
            Rname: Rname,
            name: foodName,
            image: foodImg,
            price : foodPrice
        })

         //Sava the data in database
         const foodData = await addFoodData.save()
         res.redirect("/Foodmanagement")

       
})


// // ### Food Increase ### // //

Router.post('/canteen/user/foodIncrease', async (req, res) => {
    console.log(req.body.FoodPrice)
    let foodID = req.body.id
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    let Cart = await cartCollection.findOne({ customerId: verifyUser })
    // if (req.session.cart[req.body.UserID].items[foodID].qty < 10) {
    //     req.session.cart[req.body.UserID].items[foodID].qty = req.session.cart[req.body.UserID].items[foodID].qty + 1
    //     req.session.cart[req.body.UserID].totalQty = req.session.cart[req.body.UserID].totalQty + 1
    //     req.session.cart[req.body.UserID].totalPrice += Number(req.body.FoodPrice)
    // }
    // else {
    //     req.flash('error', "Sorry! maximum limit has been crossed")
    // }


    let itemIndex = Cart.items.findIndex(p => p.productId == foodID);
    if (Cart.items[itemIndex].quantity < 10) {
        console.log(itemIndex)
        let productItem = Cart.items[itemIndex];
        productItem.quantity += 1;
        //productItem.productPrice = req.body.FoodPrice * productItem.quantity
        Cart.items[itemIndex] = productItem;
        Cart.totalQty += 1
        Cart.totalPrice += parseInt(req.body.FoodPrice);

        Cart = await Cart.save();
    } else {

        req.flash('error', "Sorry! maximum limit has been crossed")
        // res.redirect("/yourOrders")
    }

    res.json({ totalQty: Cart.totalQty })

    // res.json({ foodID: req.session.cart[req.body.UserID].items[foodID].item._id, Foodqty: req.session.cart[req.body.UserID].items[foodID].qty, foodTotal: req.session.cart[req.body.UserID].totalQty, itemPrice: req.session.cart[req.body.UserID].items[foodID].item.price })
})

// // ### Food Decrease ### // //

Router.post('/canteen/user/food-Decrease', async (req, res) => {
    // console.log(req.body.id)
    // let foodID = req.body.id

    // req.session.cart[req.body.UserID].items[foodID].qty = req.session.cart[req.body.UserID].items[foodID].qty - 1
    // req.session.cart[req.body.UserID].totalQty = req.session.cart[req.body.UserID].totalQty - 1
    // req.session.cart[req.body.UserID].totalPrice -= Number(req.body.FoodPrice)

    // // console.log(req.session.cart[req.body.UserID])
    // // console.log(typeof(req.body.FoodPrice) )


    // res.json({ foodID: req.session.cart[req.body.UserID].items[foodID].item._id, Foodqty: req.session.cart[req.body.UserID].items[foodID].qty, foodTotal: req.session.cart[req.body.UserID].totalQty, itemPrice: req.session.cart[req.body.UserID].items[foodID].item.price })
    console.log(req.body.FoodPrice)
    let foodID = req.body.foodId
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    let Cart = await cartCollection.findOne({ customerId: verifyUser })
    let itemIndex = Cart.items.findIndex(p => p.productId == foodID);

    console.log(itemIndex)
    let productItem = Cart.items[itemIndex];
    productItem.quantity -= 1;
    //productItem.productPrice = req.body.FoodPrice * productItem.quantity
    Cart.items[itemIndex] = productItem;
    Cart.totalQty -= 1
    Cart.totalPrice -= parseInt(req.body.FoodPrice);

    Cart = await Cart.save();

    res.json({ totalQty: Cart.totalQty })
})

// // ### Food Delete ### // //

Router.post('/canteen/user/food-Delete', async (req, res) => {
    //console.log(req.body.foodId)
    let foodID = req.body.foodId
    const login_cookie_token = req.cookies.jwtLOGIN
    const verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    let Cart = await cartCollection.findOne({ customerId: verifyUser._id })
    let itemIndex = Cart.items.findIndex(p => p.productId == foodID);
    console.log(itemIndex)

    if(Cart.totalQty > 1){
        Cart.items.splice(itemIndex, 1)
        Cart.totalQty -= 1
        Cart.totalPrice -= req.body.FoodPrice
        Cart = await Cart.save();
        res.json({ totalQty: Cart.totalQty })
    }else{
        Cart.deleteOne({customerId: verifyUser._id })
        res.json({ totalQty: Cart.totalQty })
    }

    

    //delete req.session.cart[req.body.UserID].items[req.body.foodId]

    //Cart.update([{customerId: verifyUser}, {$unset: "items[itemIndex]"}]);

    // req.session.cart[req.body.UserID].totalQty = req.session.cart[req.body.UserID].totalQty - 1
    // req.session.cart[req.body.UserID].totalPrice -= req.body.FoodPrice

    // if (req.session.cart[req.body.UserID].totalQty == 0) {
    //     delete req.session.cart[req.body.UserID]
    // }

    // res.json(req.session.cart)

    // console.log('Session', req.session.cart[req.body.UserID])
})

Router.post('/user/Order/confirmed-order', async (req, res) => {

    const login_cookie_token = req.cookies.jwtLOGIN
    var verifyUser = await jwt.verify(login_cookie_token, "uemCanteen")
    console.log(verifyUser)
    let user = await userSchema.findOne({_id: verifyUser._id})
    let Cart = await cartCollection.findOne({ customerId: verifyUser._id }, { items: 1, totalQty: 1, totalPrice: 1, _id: 0 })
    console.log("Cartttt", verifyUser)

    if (verifyUser) {
        const order = new Order({
            customerId: verifyUser._id,
            customerDetails : {
                customerName : verifyUser.username,
                customerPhone : user.contactNo,
                customerEmail : verifyUser.userEmail,
            },
            items: Cart,
            status: "Pending"
        })
        order.save().then(async result => {
            // console.log(result)
            // req.flash("success", "Order success")
            await cartCollection.deleteOne({ customerId: verifyUser._id })
            // delete req.session.cart[verifyUser._id]
            return res.redirect('/Orderconfirmed')
        }).catch(err => {
            req.flash('error', "Somthing went wrong")
            console.log(err)
            return res.redirect('/yourOrders')
        })

    }

})

Router.post('/payment-status', async (req, res)=>{
    let b = req.body.cID
    await Orders.updateOne({_id : b }, {$set:{status:"Success"}})
    let d = await Orders.findOne({ _id : b })
    console.log("Ju",d)
    res.json(d)
})


// Export the page
module.exports = Router